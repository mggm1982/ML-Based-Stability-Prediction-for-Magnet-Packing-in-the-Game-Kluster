"""Kluster magnet-stability project."""
